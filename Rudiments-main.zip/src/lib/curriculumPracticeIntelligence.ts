import {
  AssistanceLevel,
  CurriculumBand,
  CurriculumCompetency,
  CurriculumMissionMetadata,
  LearnerProfile,
  PracticeExercise,
  PracticeSession,
  SelfCheckFeeling,
} from '../types';
import { getCurriculumPedagogyProfile } from './curriculumPedagogyEngine';
import { CURRICULUM_COMPETENCIES_BY_ID } from '../data/canonicalCurriculum';
import { getAttemptsForSkill } from './evidenceEngine';
import {
  C9_RUDIMENT_APPLICATION_EVIDENCE_VERSION,
  getRudimentApplicationPlan,
  isQualifiedRudimentApplicationExercise,
} from './rudimentApplicationEngine';

const C6_EVIDENCE_KEY = 'RUDIMENT_C6_CURRICULUM_EVIDENCE_V1';

// C7.6 shared migration boundary. Notation evidence created before the corrected
// C7.4 staff/transport build must not be promoted into canonical readiness.
export const C7_NOTATION_VALID_EVIDENCE_SINCE = Date.parse('2026-09-07T19:29:00Z');

// C7.13 groove-integrity boundary. Earlier Groove Stability Mission 5/6 runs
// used an 8/16-bar curriculum visualizer over a shorter generic transport loop,
// and the musical-transfer mission had no real section/dynamic responsibility.
// Preserve the learner's conceptual/guided evidence, but require fresh
// independent + musical-transfer evidence on the corrected long-form transport.
export const C7_GROOVE_STABILITY_VALID_TRANSFER_SINCE = Date.parse('2026-09-08T09:00:00Z');

// C10 full-song boundary. Earlier Full Song M5/M6 runs used the generic short
// phrase transport. Preserve M1-M4 learning evidence, but require fresh long-form
// independent and musical-performance evidence on the 60-bar / 3:00 architecture.
export const C10_FULL_SONG_VALID_TRANSFER_SINCE = Date.parse('2026-09-16T10:25:00Z');

function isC7IntegrityValid(competencyId: string, missionNumber: number, timestamp: string): boolean {
  if (competencyId === 'comp-grv-stability' && missionNumber >= 5) {
    return new Date(timestamp).getTime() >= C7_GROOVE_STABILITY_VALID_TRANSFER_SINCE;
  }
  if (competencyId === 'comp-perf-song-app' && missionNumber >= 5) {
    return new Date(timestamp).getTime() >= C10_FULL_SONG_VALID_TRANSFER_SINCE;
  }
  return true;
}

export interface CurriculumMissionEvidenceRecord {
  id: string;
  runId: string;
  sessionId: string;
  competencyId: string;
  missionId: string;
  missionNumber: number;
  timestamp: string;
  date: string;
  bpm: number;
  assessment: SelfCheckFeeling;
  assistanceLevel: AssistanceLevel;
  conceptualTarget: boolean;
  executionTarget: boolean;
  musicalApplication: boolean;
  applicationKind?: 'RUDIMENT_ORCHESTRATION';
  applicationEvidenceVersion?: string;
  applicationEvidenceQualified?: boolean;
  applicationRunKey?: string;
  applicationCompletedLoops?: number;
  applicationRequiredLoops?: number;
  issueTags: string[];
  pedagogyDomain?: string;
}

export interface CurriculumEvidenceLedger {
  competencyId: string;
  totalAttempts: number;
  guidedSuccesses: number;
  reducedSuccesses: number;
  independentCleanRuns: number;
  conceptualDemonstrations: number;
  musicalApplications: number;
  separateSessions: number;
  separateDays: number;
  highestCleanTempo: number | null;
  readiness: number;
  readinessCriteria: Array<{ label: string; met: boolean; detail: string }>;
  recentRecords: CurriculumMissionEvidenceRecord[];
}

function readAllEvidence(): CurriculumMissionEvidenceRecord[] {
  try {
    const raw = localStorage.getItem(C6_EVIDENCE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeAllEvidence(records: CurriculumMissionEvidenceRecord[]) {
  try {
    localStorage.setItem(C6_EVIDENCE_KEY, JSON.stringify(records.slice(-800)));
  } catch (error) {
    console.warn('[C6] Could not persist curriculum evidence', error);
  }
}

function hasQualifiedApplicationTransport(input: {
  applicationEvidenceQualified?: boolean;
  applicationRunKey?: string;
  applicationCompletedLoops?: number;
  applicationRequiredLoops?: number;
}): boolean {
  const required = Math.max(1, input.applicationRequiredLoops || 1);
  return Boolean(
    input.applicationEvidenceQualified === true &&
    input.applicationRunKey &&
    (input.applicationCompletedLoops || 0) >= required
  );
}

export function recordCurriculumMissionEvidence(input: {
  sessionId: string;
  exercise: PracticeExercise;
  assessment: SelfCheckFeeling;
  bpm: number;
  assistanceLevel?: AssistanceLevel;
  issueTags?: string[];
  completedAt?: string;
  applicationEvidenceQualified?: boolean;
  applicationRunKey?: string;
  applicationCompletedLoops?: number;
  applicationRequiredLoops?: number;
}): CurriculumMissionEvidenceRecord | null {
  const mission = input.exercise.curriculumMission;
  if (!mission) return null;

  const timestamp = input.completedAt || new Date().toISOString();
  const runIdentity = input.applicationRunKey || timestamp;
  const runId = `${input.sessionId}:${input.exercise.id}:${runIdentity}`;
  const all = readAllEvidence();
  const existing = all.find((record) => record.runId === runId);
  if (existing) return existing;

  const record: CurriculumMissionEvidenceRecord = {
    id: `c6-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    runId,
    sessionId: input.sessionId,
    competencyId: mission.competencyId,
    missionId: mission.missionId,
    missionNumber: mission.missionNumber,
    timestamp,
    date: timestamp.slice(0, 10),
    bpm: input.bpm,
    assessment: input.assessment,
    assistanceLevel: input.assistanceLevel || mission.assistanceTarget,
    conceptualTarget: Boolean(mission.conceptualTarget),
    executionTarget: Boolean(mission.executionTarget),
    // C9.2: a rudiment Mission 6 becomes a musical-use record only when
    // the dedicated orchestration contract rendered AND the governed PLAY run
    // completed its required phrase cycles. Opening Mission 6, aborting a run,
    // or evaluating stale UI state cannot create musical-application evidence.
    musicalApplication: mission.pedagogyDomain === 'RUDIMENT'
      ? isQualifiedRudimentApplicationExercise(input.exercise) && hasQualifiedApplicationTransport(input)
      : Boolean(mission.musicalApplication),
    applicationKind: isQualifiedRudimentApplicationExercise(input.exercise)
      ? 'RUDIMENT_ORCHESTRATION'
      : undefined,
    applicationEvidenceVersion: isQualifiedRudimentApplicationExercise(input.exercise)
      ? C9_RUDIMENT_APPLICATION_EVIDENCE_VERSION
      : undefined,
    applicationEvidenceQualified: isQualifiedRudimentApplicationExercise(input.exercise)
      ? hasQualifiedApplicationTransport(input)
      : undefined,
    applicationRunKey: isQualifiedRudimentApplicationExercise(input.exercise) ? input.applicationRunKey : undefined,
    applicationCompletedLoops: isQualifiedRudimentApplicationExercise(input.exercise) ? input.applicationCompletedLoops : undefined,
    applicationRequiredLoops: isQualifiedRudimentApplicationExercise(input.exercise) ? input.applicationRequiredLoops : undefined,
    issueTags: input.issueTags || [],
    pedagogyDomain: mission.pedagogyDomain,
  };

  writeAllEvidence([...all, record]);
  window.dispatchEvent(new CustomEvent('rudiment:c6-evidence-updated', { detail: { competencyId: mission.competencyId } }));
  return record;
}

function missionNumberFromExerciseId(exerciseId: string): number | null {
  const match = (exerciseId || '').match(/(?:-c6)?-m(\d+)$/i);
  if (!match) return null;
  const value = Number(match[1]);
  return Number.isFinite(value) ? value : null;
}

function inferredCanonicalAssistance(competencyId: string, missionNumber: number): AssistanceLevel {
  if (competencyId === 'comp-meter-44') {
    if (missionNumber <= 3) return 'FULL';
    if (missionNumber <= 6) return 'REDUCED';
    return 'NONE';
  }
  if (missionNumber <= 3) return 'FULL';
  if (missionNumber === 4) return 'REDUCED';
  return 'NONE';
}

function canonicalMissionFlags(competencyId: string, missionNumber: number) {
  if (competencyId === 'comp-meter-44') {
    return {
      conceptualTarget: missionNumber !== 6,
      executionTarget: true,
      musicalApplication: missionNumber === 5 || missionNumber === 8,
    };
  }
  return {
    conceptualTarget: missionNumber <= 3,
    executionTarget: missionNumber >= 2,
    musicalApplication: missionNumber === 6,
  };
}

function assessmentFromPracticeAttempt(
  assessment: ReturnType<typeof getAttemptsForSkill>[number]['assessment']
): SelfCheckFeeling {
  if (assessment === 'clean_relaxed') return 'CLEAN_AND_RELAXED';
  if (assessment === 'mostly_clean') return 'MOSTLY_CLEAN';
  if (assessment === 'inconsistent') return 'INCONSISTENT';
  return 'TOO_DIFFICULT';
}

function isCanonicalExerciseForCompetency(competencyId: string, exerciseId: string): boolean {
  const id = exerciseId || '';
  return id.startsWith(`c6-${competencyId}-`) || id.startsWith(`c7-${competencyId}-`);
}

/**
 * Returns the canonical curriculum evidence stream for one competency.
 *
 * C7.6 also reconstructs valid C6/C7 mission evidence from the generic attempt
 * store when an older build recorded the practice attempt but did not yet write
 * the dedicated curriculum ledger. Direct curriculum records always win, so the
 * reconstruction never double-counts the same mission in the same session.
 */
export function getCurriculumEvidenceRecords(competencyId: string): CurriculumMissionEvidenceRecord[] {
  const direct = readAllEvidence()
    .filter((record) => record.competencyId === competencyId)
    .filter((record) =>
      competencyId !== 'comp-reading-notation' ||
      new Date(record.timestamp).getTime() >= C7_NOTATION_VALID_EVIDENCE_SINCE
    )
    .filter((record) => isC7IntegrityValid(competencyId, record.missionNumber, record.timestamp))
    .map((record) => {
      // C9 evidence migration: only the corrected five-bar orchestration contract
      // may satisfy musical application. Preserve older attempt/session history,
      // but do not upgrade C8 or pre-C8 records into C9 evidence.
      if (record.pedagogyDomain === 'RUDIMENT' && record.missionNumber === 6) {
        const validApplication =
          record.applicationKind === 'RUDIMENT_ORCHESTRATION' &&
          record.applicationEvidenceVersion === C9_RUDIMENT_APPLICATION_EVIDENCE_VERSION &&
          hasQualifiedApplicationTransport(record);
        return { ...record, musicalApplication: validApplication, applicationEvidenceQualified: validApplication };
      }
      return record;
    });
  const competency = CURRICULUM_COMPETENCIES_BY_ID.get(competencyId);
  if (!competency) return direct;

  const directMissionKeys = new Set(
    direct.map((record) => `${record.sessionId}:${record.missionNumber}`)
  );
  const pedagogy = getCurriculumPedagogyProfile(competency);

  const reconstructed = getAttemptsForSkill(competency.skillId)
    .filter((attempt) => isCanonicalExerciseForCompetency(competencyId, attempt.exerciseId))
    .filter((attempt) =>
      competencyId !== 'comp-reading-notation' ||
      new Date(attempt.timestamp).getTime() >= C7_NOTATION_VALID_EVIDENCE_SINCE
    )
    .flatMap((attempt): CurriculumMissionEvidenceRecord[] => {
      const missionNumber = missionNumberFromExerciseId(attempt.exerciseId);
      if (!missionNumber) return [];
      if (!isC7IntegrityValid(competencyId, missionNumber, attempt.timestamp)) return [];

      const missionKey = `${attempt.sessionId}:${missionNumber}`;
      if (directMissionKeys.has(missionKey)) return [];

      const flags = canonicalMissionFlags(competencyId, missionNumber);
      const assistanceLevel =
        attempt.assistanceLevel || inferredCanonicalAssistance(competencyId, missionNumber);

      return [{
        id: `c7-migrated-${attempt.id}`,
        runId: `legacy-attempt:${attempt.id}`,
        sessionId: attempt.sessionId,
        competencyId,
        missionId: `${competencyId === 'comp-meter-44' ? 'c6' : 'c7'}-${competencyId}-m${missionNumber}`,
        missionNumber,
        timestamp: attempt.timestamp,
        date: attempt.timestamp.slice(0, 10),
        bpm: attempt.bpm,
        assessment: assessmentFromPracticeAttempt(attempt.assessment),
        assistanceLevel,
        conceptualTarget: flags.conceptualTarget,
        executionTarget: flags.executionTarget,
        musicalApplication: pedagogy.domain === 'RUDIMENT'
          ? flags.musicalApplication &&
            attempt.challengeType === 'kit-orchestration' &&
            attempt.applicationKind === 'RUDIMENT_ORCHESTRATION' &&
            attempt.applicationEvidenceVersion === C9_RUDIMENT_APPLICATION_EVIDENCE_VERSION &&
            hasQualifiedApplicationTransport(attempt)
          : flags.musicalApplication,
        applicationKind: pedagogy.domain === 'RUDIMENT' && attempt.challengeType === 'kit-orchestration' && attempt.applicationKind === 'RUDIMENT_ORCHESTRATION'
          ? 'RUDIMENT_ORCHESTRATION'
          : undefined,
        applicationEvidenceVersion: pedagogy.domain === 'RUDIMENT' && attempt.challengeType === 'kit-orchestration'
          ? attempt.applicationEvidenceVersion
          : undefined,
        applicationEvidenceQualified: pedagogy.domain === 'RUDIMENT' && flags.musicalApplication
          ? hasQualifiedApplicationTransport(attempt)
          : undefined,
        applicationRunKey: attempt.applicationRunKey,
        applicationCompletedLoops: attempt.applicationCompletedLoops,
        applicationRequiredLoops: attempt.applicationRequiredLoops,
        issueTags: attempt.frictions || [],
        pedagogyDomain: pedagogy.domain,
      }];
    });

  return [...direct, ...reconstructed].sort((a, b) => a.timestamp.localeCompare(b.timestamp));
}

export function getCurriculumEvidenceLedger(competencyId: string): CurriculumEvidenceLedger {
  const records = getCurriculumEvidenceRecords(competencyId);
  const success = (record: CurriculumMissionEvidenceRecord) =>
    record.assessment === 'CLEAN_AND_RELAXED' || record.assessment === 'MOSTLY_CLEAN';
  const clean = (record: CurriculumMissionEvidenceRecord) => record.assessment === 'CLEAN_AND_RELAXED';

  const guidedSuccesses = records.filter((record) => success(record) && record.assistanceLevel === 'FULL').length;
  const reducedSuccesses = records.filter((record) => success(record) && record.assistanceLevel === 'REDUCED').length;
  const independentCleanRuns = records.filter(
    (record) => clean(record) && (record.assistanceLevel === 'MINIMAL' || record.assistanceLevel === 'NONE')
  ).length;
  const conceptualDemonstrations = records.filter((record) => success(record) && record.conceptualTarget).length;
  const musicalApplications = records.filter((record) => success(record) && record.musicalApplication).length;
  const separateSessions = new Set(records.map((record) => record.sessionId)).size;
  const separateDays = new Set(records.map((record) => record.date)).size;
  const cleanTempos = records.filter(clean).map((record) => record.bpm);
  const highestCleanTempo = cleanTempos.length ? Math.max(...cleanTempos) : null;

  const competencyStub = { id: competencyId } as CurriculumCompetency;
  const profile = getCurriculumPedagogyProfile(competencyStub);
  const labels = profile.evidenceLabels;
  const readinessCriteria = [
    {
      label: labels[0],
      met: conceptualDemonstrations >= 1,
      detail: `${conceptualDemonstrations} demonstrated conceptual run${conceptualDemonstrations === 1 ? '' : 's'}`,
    },
    {
      label: labels[1],
      met: guidedSuccesses >= 1,
      detail: `${guidedSuccesses} controlled guided run${guidedSuccesses === 1 ? '' : 's'}`,
    },
    {
      label: labels[2],
      met: reducedSuccesses >= 1,
      detail: `${reducedSuccesses} controlled reduced-cue run${reducedSuccesses === 1 ? '' : 's'}`,
    },
    {
      label: labels[4],
      met: independentCleanRuns >= 2,
      detail: `${independentCleanRuns}/2 clean independent runs`,
    },
    {
      label: labels[5],
      met: musicalApplications >= 1,
      detail: `${musicalApplications} successful musical application${musicalApplications === 1 ? '' : 's'}`,
    },
    {
      label: 'Learning revisited separately',
      met: separateSessions >= 2,
      detail: `${separateSessions}/2 separate curriculum sessions (coverage only; C4 still requires separate qualifying independent sessions)`,
    },
  ];

  return {
    competencyId,
    totalAttempts: records.length,
    guidedSuccesses,
    reducedSuccesses,
    independentCleanRuns,
    conceptualDemonstrations,
    musicalApplications,
    separateSessions,
    separateDays,
    highestCleanTempo,
    readiness: readinessCriteria.filter((criterion) => criterion.met).length,
    readinessCriteria,
    recentRecords: [...records].sort((a, b) => b.timestamp.localeCompare(a.timestamp)).slice(0, 8),
  };
}

function personalizedDepth(band: CurriculumBand): 'FOUNDATION' | 'CONDENSED' | 'DIAGNOSTIC' {
  if (band === 'ADVANCED') return 'DIAGNOSTIC';
  if (band === 'INTERMEDIATE') return 'CONDENSED';
  return 'FOUNDATION';
}

function startTempoForBand(target: number, band: CurriculumBand): number {
  if (band === 'ADVANCED') return Math.max(40, Math.min(target, Math.round(target * 0.95)));
  if (band === 'INTERMEDIATE') return Math.max(40, Math.round(target * 0.9));
  return Math.max(40, Math.round(target * 0.8));
}

function mission(
  sessionId: string,
  competency: CurriculumCompetency,
  n: number,
  title: string,
  purpose: string,
  instructions: string,
  tempo: number,
  durationSeconds: number,
  stage: CurriculumMissionMetadata['stage'],
  assistance: AssistanceLevel,
  totalBars: number,
  phraseGroupSize: number,
  options: Partial<CurriculumMissionMetadata> = {},
): PracticeExercise {
  const metadata: CurriculumMissionMetadata = {
    competencyId: competency.id,
    missionId: `c6-${competency.id}-m${n}`,
    missionNumber: n,
    missionTitle: title,
    stage,
    assistanceTarget: assistance,
    conceptualTarget: options.conceptualTarget ?? true,
    executionTarget: options.executionTarget ?? true,
    musicalApplication: options.musicalApplication ?? false,
    patternDisplay: options.patternDisplay ?? 'BAR_STRUCTURE',
    requiredPatternLabel: options.requiredPatternLabel,
    structure: options.structure || {
      totalBars,
      phraseGroupSize,
      beatsPerBar: 4,
      highlightLandmarkBars: totalBars >= 16 ? [1, 5, 9, 13] : totalBars >= 8 ? [1, 5] : [1],
      showBarNumbers: true,
      showBeatNumbers: true,
    },
  };

  return {
    id: `${sessionId}-c6-m${n}`,
    title,
    phase: n === 1 ? 'FOUNDATION' : n >= 7 ? 'APPLICATION' : 'MAIN WORK',
    skillIds: [competency.skillId],
    purpose,
    whyThisExercise: purpose,
    pedagogicalRole: n >= 7 ? 'INDEPENDENCE TEST' : n === 1 ? 'PREPARATION' : 'PRIMARY TARGET',
    instructions,
    sticking: undefined,
    counting: competency.countingPattern,
    timeSignature: '4/4',
    subdivision: 'Quarter Notes',
    tempo,
    targetTempo: competency.tempoStandard.bpm,
    durationSeconds,
    exerciseType: n >= 5 ? 'application' : 'coordination',
    equipmentRequired: n >= 5 ? 'Full Drum Kit' : 'Either',
    difficulty: n >= 7 ? 'Challenging' : n >= 4 ? 'Moderate' : 'Easy',
    curriculumMission: metadata,
    progressionStage: n >= 5 ? 'TRANSFER' : n >= 3 ? 'APPLICATION' : 'FOUNDATION',
    challengeType: n >= 5 ? 'groove-phrase' : 'precision-mechanics',
    sessionSource: 'C7_CANONICAL_COMPETENCY',
    skillId: competency.skillId,
  };
}

export function buildC6CompetencySession(
  competency: CurriculumCompetency,
  profile: LearnerProfile,
  placementBand: CurriculumBand
): PracticeSession {
  const sessionId = `c6-${competency.id}-${Date.now()}`;
  const target = competency.tempoStandard.bpm;
  const base = startTempoForBand(target, placementBand);
  const depth = personalizedDepth(placementBand);
  const equipment = profile.equipment === 'Practice Pad' ? 'Practice Pad' : 'Full Drum Kit';

  if (competency.id !== 'comp-meter-44') {
    throw new Error('C6 specialized journey is currently authored for Understanding 4/4 Bar Structure.');
  }

  const exercises: PracticeExercise[] = [
    mission(
      sessionId,
      competency,
      1,
      'Mission 1 — Feel One Bar',
      'Separate beat number from bar number and feel Beat 1 as the reset point.',
      'Play one relaxed quarter note on every beat. Count 1 2 3 4, then restart at 1 without adding or dropping a beat.',
      base,
      45,
      'UNDERSTAND',
      'FULL',
      2,
      1,
      { conceptualTarget: true, executionTarget: true }
    ),
    mission(
      sessionId,
      competency,
      2,
      'Mission 2 — Hear the Barline',
      'Keep the pulse while hearing where one bar ends and the next begins.',
      'Continue quarter notes while listening for the stronger Bar-1 landmark. Say the beat numbers, but let the bar reset happen internally.',
      base,
      60,
      'INTERNALIZE',
      'FULL',
      4,
      1,
      { conceptualTarget: true, executionTarget: true }
    ),
    mission(
      sessionId,
      competency,
      3,
      'Mission 3 — Four-Bar Phrase',
      'Track four complete bars without confusing beat count with bar count.',
      'Play four continuous bars. Know when Bar 1, Bar 2, Bar 3 and Bar 4 begin, then return confidently to Bar 1.',
      Math.min(target, base + 2),
      75,
      'HEAR',
      'FULL',
      4,
      4,
      { conceptualTarget: true, executionTarget: true }
    ),
    mission(
      sessionId,
      competency,
      4,
      'Mission 4 — Eight-Bar Structure',
      'Own two groups of four bars while tutor support begins to fade.',
      'Play eight bars as 4 + 4. Track the midpoint at Bar 5 and return to the same relaxed pulse without relying on constant spoken bar numbers.',
      Math.min(target, base + 4),
      90,
      'FOLLOW',
      'REDUCED',
      8,
      4,
      { conceptualTarget: true, executionTarget: true }
    ),
    mission(
      sessionId,
      competency,
      5,
      'Mission 5 — Section Awareness',
      'Connect bar counting to musical form instead of treating it as a counting exercise only.',
      'Keep a simple pulse through Intro 4 bars, Verse 8 bars, Chorus 8 bars and Outro 4 bars. Notice the section changes without stopping.',
      Math.min(target, base + 4),
      105,
      'FOLLOW',
      'REDUCED',
      24,
      4,
      {
        conceptualTarget: true,
        executionTarget: true,
        musicalApplication: true,
        structure: {
          totalBars: 24,
          phraseGroupSize: 4,
          beatsPerBar: 4,
          highlightLandmarkBars: [1, 5, 13, 21],
          showBarNumbers: true,
          showBeatNumbers: true,
          sections: [
            { label: 'Intro', startBar: 1, bars: 4 },
            { label: 'Verse', startBar: 5, bars: 8 },
            { label: 'Chorus', startBar: 13, bars: 8 },
            { label: 'Outro', startBar: 21, bars: 4 },
          ],
        },
      }
    ),
    mission(
      sessionId,
      competency,
      6,
      'Mission 6 — Reduced Guidance',
      'Hold the phrase when spoken bar numbers disappear.',
      'Play eight bars with the click and only subtle Bar-1 guidance. If you lose the form, recover at the next four-bar landmark rather than stopping.',
      Math.min(target, base + 6),
      90,
      'REDUCED',
      'REDUCED',
      8,
      4,
      { conceptualTarget: false, executionTarget: true }
    ),
    mission(
      sessionId,
      competency,
      7,
      'Mission 7 — Independent Phrase Test',
      'Demonstrate 16-bar phrase ownership without tutor performance.',
      'Metronome only. Play 16 uninterrupted bars and know exactly when Bars 1, 5, 9 and 13 begin.',
      Math.min(target, base + 8),
      120,
      'INDEPENDENT',
      'NONE',
      16,
      4,
      { conceptualTarget: true, executionTarget: true }
    ),
    mission(
      sessionId,
      competency,
      8,
      'Mission 8 — Musical Transfer',
      'Carry 4/4 phrase awareness into a complete slow worship-style arrangement.',
      'Play a simple musical groove through the arrangement. Keep the form internally and recognize section boundaries without stopping.',
      target,
      120,
      'MUSICAL_APPLICATION',
      'NONE',
      24,
      4,
      {
        conceptualTarget: true,
        executionTarget: true,
        musicalApplication: true,
        structure: {
          totalBars: 24,
          phraseGroupSize: 4,
          beatsPerBar: 4,
          highlightLandmarkBars: [1, 5, 13, 21],
          showBarNumbers: true,
          showBeatNumbers: true,
          sections: [
            { label: 'Intro', startBar: 1, bars: 4 },
            { label: 'Verse', startBar: 5, bars: 8 },
            { label: 'Chorus', startBar: 13, bars: 8 },
            { label: 'Outro', startBar: 21, bars: 4 },
          ],
        },
      }
    ),
  ];

  // Intermediate and Advanced placement compresses explanation and begins closer
  // to the target tempo, but every canonical mission remains present and must be
  // evidenced independently before formal verification.
  return {
    id: sessionId,
    date: new Date().toISOString().slice(0, 10),
    durationMinutes: placementBand === 'BEGINNER' ? 20 : 15,
    practiceContext: profile.practicePriority === 'Song / Performance Preparation' ? 'SONG_SERVICE_PREP' : profile.practicePriority === 'Balanced' ? 'BALANCED' : 'SKILL_DEVELOPMENT',
    equipment,
    focusMode: 'COACH_CHOOSES',
    selectedSkillIds: [competency.skillId],
    skillId: competency.skillId,
    focusTopic: `${competency.title} — C7 Canonical Learning Journey`,
    notes: `${placementBand} placement personalizes teaching depth only. Competency remains unverified until formal C4 verification passes.`,
    rating: 5,
    exercises,
    sessionStatus: 'NOT_STARTED',
    sessionSource: 'C7_CANONICAL_COMPETENCY',
    curriculumPractice: {
      competencyId: competency.id,
      placementBand,
      journeyVersion: 'C7',
      missionCount: exercises.length,
      personalizedDepth: depth,
    },
  };
}


function c7EquipmentFor(competency: CurriculumCompetency, profile: LearnerProfile): PracticeExercise['equipmentRequired'] {
  if (competency.supportedEquipment === 'Practice Pad') return 'Practice Pad';
  if (competency.supportedEquipment === 'Full Drum Kit') return 'Full Drum Kit';
  if (profile.equipment === 'Practice Pad') return 'Practice Pad';
  if (profile.equipment === 'Full Drum Kit') return 'Full Drum Kit';
  return 'Either';
}

function c7ExerciseType(domain: ReturnType<typeof getCurriculumPedagogyProfile>['domain'], musical: boolean): PracticeExercise['exerciseType'] {
  if (musical) return 'application';
  if (domain === 'RUDIMENT' || domain === 'PULSE_SUBDIVISION' || domain === 'READING') return 'technique';
  if (domain === 'FILL_TRANSITION') return 'fill';
  if (domain === 'GROOVE' || domain === 'STYLE' || domain === 'PERFORMANCE' || domain === 'DYNAMICS') return 'groove';
  return 'coordination';
}

function c7TimeSignature(competency: CurriculumCompetency): string {
  if (competency.id.includes('meter-68') || competency.id.includes('worship-68')) return '6/8';
  if (competency.id.includes('meter-34')) return '3/4';
  if (competency.id.includes('meter-54')) return '5/4';
  if (competency.id.includes('meter-78')) return '7/8';
  if (competency.id.includes('meter-128')) return '12/8';
  return '4/4';
}

function performanceSectionsForBars(bars: number) {
  if (bars >= 60) {
    return [
      { label: 'INTRO', startBar: 1, bars: 4, intensity: 'SOFT' as const, performanceCue: 'Establish the pocket; no fill is required.' },
      { label: 'VERSE A', startBar: 5, bars: 12, intensity: 'SOFT' as const, performanceCue: 'Keep the texture restrained and protect the imagined vocal.' },
      { label: 'CHORUS A', startBar: 17, bars: 12, intensity: 'STRONG' as const, performanceCue: 'Lift energy without changing tempo or abandoning the pocket.' },
      { label: 'VERSE RETURN', startBar: 29, bars: 12, intensity: 'SOFT' as const, performanceCue: 'Come down immediately while keeping the same internal pulse.' },
      { label: 'BRIDGE BUILD', startBar: 41, bars: 8, intensity: 'MEDIUM' as const, performanceCue: 'Build gradually across the section; do not peak early.' },
      { label: 'FINAL CHORUS', startBar: 49, bars: 8, intensity: 'STRONG' as const, performanceCue: 'Use the strongest version of the groove with controlled musical choices.' },
      { label: 'OUTRO', startBar: 57, bars: 4, intensity: 'SOFT' as const, performanceCue: 'Reduce density, recover the simple pocket, and finish without rushing.' },
    ];
  }
  if (bars >= 32) {
    return [
      { label: 'INTRO', startBar: 1, bars: 4, intensity: 'SOFT' as const, performanceCue: 'Settle the pulse and leave space.' },
      { label: 'VERSE', startBar: 5, bars: 8, intensity: 'SOFT' as const, performanceCue: 'Protect the vocal space and keep the groove simple.' },
      { label: 'CHORUS', startBar: 13, bars: 8, intensity: 'STRONG' as const, performanceCue: 'Lift energy while preserving identical tempo.' },
      { label: 'VERSE RETURN', startBar: 21, bars: 8, intensity: 'SOFT' as const, performanceCue: 'Return to the simpler texture immediately.' },
      { label: 'OUTRO', startBar: 29, bars: 4, intensity: 'SOFT' as const, performanceCue: 'Finish calmly and in time.' },
    ];
  }
  if (bars >= 24) {
    return [
      { label: 'INTRO', startBar: 1, bars: 4, intensity: 'SOFT' as const, performanceCue: 'Hear where the arrangement begins.' },
      { label: 'VERSE', startBar: 5, bars: 8, intensity: 'SOFT' as const, performanceCue: 'Recognize the restrained section sound.' },
      { label: 'CHORUS', startBar: 13, bars: 8, intensity: 'STRONG' as const, performanceCue: 'Hear the lift without hearing a tempo increase.' },
      { label: 'OUTRO', startBar: 21, bars: 4, intensity: 'SOFT' as const, performanceCue: 'Recognize the deliberate drop in density.' },
    ];
  }
  if (bars >= 16) {
    return [
      { label: 'INTRO', startBar: 1, bars: 4, intensity: 'SOFT' as const, performanceCue: 'Count four bars and locate the first section boundary.' },
      { label: 'VERSE', startBar: 5, bars: 8, intensity: 'SOFT' as const, performanceCue: 'Track 4-bar groups inside the verse.' },
      { label: 'CHORUS ENTRY', startBar: 13, bars: 4, intensity: 'STRONG' as const, performanceCue: 'Feel the section change without changing the quarter-note pulse.' },
    ];
  }
  return [
    { label: 'INTRO', startBar: 1, bars: 4, intensity: 'SOFT' as const, performanceCue: 'Locate the beginning and establish the pulse.' },
    { label: 'VERSE ENTRY', startBar: 5, bars: Math.max(1, bars - 4), intensity: 'SOFT' as const, performanceCue: 'Recognize the first section handoff.' },
  ];
}

function c7StructureFor(
  competency: CurriculumCompetency,
  bars: number,
  domain?: ReturnType<typeof getCurriculumPedagogyProfile>['domain'],
  missionNumber?: number
) {
  const meter = c7TimeSignature(competency);
  const beatsPerBar = meter === '6/8' ? 6 : meter === '3/4' ? 3 : meter === '5/4' ? 5 : meter === '7/8' ? 7 : meter === '12/8' ? 12 : 4;
  const base = {
    totalBars: bars,
    phraseGroupSize: bars >= 8 ? 4 : Math.max(1, Math.min(4, bars)),
    beatsPerBar,
    highlightLandmarkBars: bars >= 16 ? [1, 5, 9, 13] : bars >= 8 ? [1, 5] : [1],
    showBarNumbers: true,
    showBeatNumbers: true,
  };

  // C10: performance work is governed by arrangement sections, not a generic
  // phrase loop. The final two missions use the complete 60-bar / 3:00 form.
  if (competency.id === 'comp-perf-song-app' && domain === 'PERFORMANCE') {
    const sections = performanceSectionsForBars(bars);
    return {
      ...base,
      phraseGroupSize: 4,
      highlightLandmarkBars: sections.map((section) => section.startBar),
      sections,
    };
  }

  // C7.13: the final groove transfer mission must be a real musical form, not
  // another static two-bar loop carrying a "Serve the Song" label. Give the
  // 16-bar journey explicit section/dynamic responsibilities so the learner has
  // something musical to respond to while preserving identical tempo/pocket.
  if (domain === 'GROOVE' && missionNumber === 6 && bars >= 16) {
    return {
      ...base,
      sections: [
        { label: 'VERSE', startBar: 1, bars: 4, intensity: 'SOFT' as const, performanceCue: 'Keep the hi-hat controlled and the backbeat firm but restrained.' },
        { label: 'CHORUS', startBar: 5, bars: 4, intensity: 'STRONG' as const, performanceCue: 'Lift the energy and backbeat without speeding up or changing the groove.' },
        { label: 'VERSE RETURN', startBar: 9, bars: 4, intensity: 'SOFT' as const, performanceCue: 'Bring the volume back down while keeping the same internal pulse.' },
        { label: 'FINAL CHORUS', startBar: 13, bars: 4, intensity: 'STRONG' as const, performanceCue: 'Lift again, stay relaxed, and finish Bar 16 without rushing.' },
      ],
    };
  }

  // C7.16: Musical Balance & Cymbal Sensitivity owns an 8-bar certification
  // standard. Its transfer mission therefore uses a real 8-bar verse/chorus
  // dynamic form instead of borrowing the generic 16-bar journey.
  if (domain === 'DYNAMICS' && competency.id === 'comp-dyn-song-balance' && missionNumber === 6 && bars >= 8) {
    return {
      ...base,
      sections: [
        { label: 'VERSE', startBar: 1, bars: 4, intensity: 'SOFT' as const, performanceCue: 'Keep closed hi-hat medium-soft. Let kick and snare remain clearly above it without changing tempo.' },
        { label: 'CHORUS', startBar: 5, bars: 4, intensity: 'STRONG' as const, performanceCue: 'Lift the kick/snare intent one level while keeping cymbals controlled. Energy rises; cymbal wash does not.' },
      ],
    };
  }

  return base;
}

/**
 * C7 generalized curriculum journey.
 * C6.1's authored 4/4 structure journey is preserved exactly, while every
 * other canonical competency now receives a pedagogy-family-specific journey
 * instead of being routed through the old generic phrase-insertion session.
 */
export function buildC7CompetencySession(
  competency: CurriculumCompetency,
  profile: LearnerProfile,
  placementBand: CurriculumBand
): PracticeSession {
  if (competency.id === 'comp-meter-44') {
    return buildC6CompetencySession(competency, profile, placementBand);
  }

  const sessionId = `c7-${competency.id}-${Date.now()}`;
  const target = competency.tempoStandard.bpm;
  const base = startTempoForBand(target, placementBand);
  const depth = personalizedDepth(placementBand);
  const pedagogy = getCurriculumPedagogyProfile(competency);
  const equipment = c7EquipmentFor(competency, profile);
  const missionCount = placementBand === 'ADVANCED' ? 6 : 6;
  const stages: CurriculumMissionMetadata['stage'][] = ['UNDERSTAND', 'INTERNALIZE', 'HEAR', 'FOLLOW', 'INDEPENDENT', 'MUSICAL_APPLICATION'];
  const assistance: AssistanceLevel[] = ['FULL', 'FULL', 'FULL', 'REDUCED', 'NONE', 'NONE'];
  // C7.4: the structural visualizer must describe the material the learner is
  // actually reading/playing. Reading missions deliberately progress through
  // 1, 1, 2, 2, 4 and 4 authored notation bars (see notationProgression.ts),
  // while the other pedagogy families keep the broader phrase-length ladder.
  // Keeping these values aligned prevents the UI from claiming an 8/16-bar
  // phrase while the staff and master transport are only presenting 2/4 bars.
  const bars = pedagogy.domain === 'READING'
    ? [1, 1, 2, 2, 4, 4]
    : competency.id === 'comp-perf-song-app'
    ? [8, 16, 24, 32, 60, 60]
    : pedagogy.domain === 'GROOVE'
    ? [2, 4, 4, 8, 16, 16]
    : competency.id === 'comp-dyn-song-balance'
    ? [2, 4, 4, 8, 8, 8]
    : [2, 4, 4, 8, 8, 16];
  const tempoOffsets = [0, 0, 2, 4, 6, target - base];

  const exercises: PracticeExercise[] = Array.from({ length: missionCount }, (_, index) => {
    const n = index + 1;
    const musical = n === 6;
    const independent = n === 5;
    const isFullSongPerformance = competency.id === 'comp-perf-song-app';
    const performanceTempos = [Math.max(60, target - 16), Math.max(64, target - 12), Math.max(68, target - 8), Math.max(72, target - 5), target, target];
    const bpm = isFullSongPerformance
      ? performanceTempos[index]
      : musical ? target : Math.min(target, base + Math.max(0, tempoOffsets[index]));
    const isReading = pedagogy.domain === 'READING';
    const isGrooveSongTransfer = pedagogy.domain === 'GROOVE' && musical;
    const isMusicalBalance = competency.id === 'comp-dyn-song-balance';
    const isGrooveToFillEntry = competency.id === 'comp-fill-entry';
    const isRudimentApplication = pedagogy.domain === 'RUDIMENT' && musical;
    const rudimentApplicationPlan = isRudimentApplication
      ? getRudimentApplicationPlan(competency)
      : null;
    const performancePurposes = [
      'Map the complete arrangement: know where Intro, Verse, Chorus, Bridge and Outro responsibilities change.',
      'Count section lengths in 4-bar groups so the arrangement stays clear without relying on a wall-clock timer.',
      'Hear the song form: recognize section energy, transition cues and the difference between a musical lift and a tempo change.',
      'Follow a 32-bar rehearsal form with reduced cues while keeping the pocket stable across every section handoff.',
      'Perform the complete 60-bar / 3:00 arrangement independently at 80 BPM with no tutor performance.',
      'Perform the complete 60-bar / 3:00 arrangement again while making restrained musical choices and recovering immediately from small errors.',
    ];
    const performanceInstructions = [
      'Study the arrangement map. Name each section, its bar length, and whether the drumming responsibility is settle, lift, build, return, or finish.',
      'Count bars in groups of four. Say the upcoming section name before its first bar while keeping the quarter-note pulse unchanged.',
      'Listen for the section changes and dynamic contour. Identify where the arrangement asks for restraint, a lift, a build, or deliberate space.',
      'Play the 32-bar rehearsal form with reduced section cues. Keep one stable pocket underneath the changes and recover immediately after any transition hesitation.',
      'Complete the entire 60-bar / 3:00 form at 80 BPM. Do not stop after a small error: recover the pocket within one bar and keep the section count moving.',
      'Complete the entire 60-bar / 3:00 form at 80 BPM and shape it musically. Use fills sparingly, preserve the pocket, match section dynamics, and finish the outro without rushing.',
    ];
    const readingPurposes = [
      'Identify the written drum voices and staff positions before playing.',
      'Count the written rhythm from left to right while keeping your eyes on the staff.',
      'Connect the moving written note positions to the exact sounds they represent.',
      'Read and play the written bar with tutor support while staying visually anchored to the staff.',
      'Sight-read the written bar independently with metronome only.',
      'Read a short drum chart in musical time without replacing notation with a memorized sticking.',
    ];
    const readingInstructions = [
      'Study the staff legend first: closed hi-hat uses an x-shaped notehead above the staff, snare sits in the middle area, and kick sits low. Name each written voice before you play.',
      `Count ${competency.tempoStandard.subdivision.toLowerCase().includes('8') ? '1 & 2 & 3 & 4 &' : competency.countingPattern} aloud while tracking the written noteheads from left to right. The staff, not an R/L mnemonic, is the source of truth.`,
      'Watch the playhead cross the notation and listen for the exact written voices. Notice simultaneous notes and any silent spaces.',
      'Follow the staff with reduced cues. Keep reading ahead by one note position so your eyes lead your limbs rather than chase them.',
      `Metronome only. Sight-read the displayed bar for ${competency.durationCriterion}. If you lose your place, stop and restart from the written beginning rather than from memory.`,
      `${competency.musicalApplicationRequirement}. Read continuously through the displayed phrase and preserve pulse, written voices and rests.`,
    ];
    const musicalBalancePurposes = [
      'Build the volume hierarchy before worrying about louder playing: cymbal underneath, kick and snare clearly on top.',
      'Keep the 1-&-2-&-3-&-4-& grid unchanged while each limb keeps its assigned dynamic role.',
      'Hear the difference between a balanced kit and cymbal wash: kick/snare stay clear while hi-hat supports rather than dominates.',
      'Follow the balanced groove with reduced tutor bars and preserve the same sound hierarchy in your response bars.',
      'Play the complete 8-bar balance standard independently with metronome only.',
      'Shape a real 8-bar Verse → Chorus form: raise musical energy without allowing cymbal volume or tempo to run away.',
    ];
    const musicalBalanceInstructions = [
      'Use closed hi-hat 8ths at medium-soft volume, firm snare on 2 and 4, and punchy kick on 1 and 3. First hear and feel which voice should sit in front and which should sit behind.',
      'Count “1 & 2 & 3 & 4 &” aloud. Keep the hi-hat low and even on every syllable while kick/snare accents land without pulling the count forward.',
      'Listen to the coach model for the mix, not just the notes. Ask: Can I hear every backbeat and kick clearly? Does the hi-hat stay supportive instead of becoming the loudest continuous sound?',
      'Use Reduced Follow. Match the tutor bar, then reproduce the same volume hierarchy in your own bar. If your right hand swells when the snare hits, lower the hi-hat immediately rather than slowing down.',
      'Metronome only. Play all 8 bars at the governed working tempo: soft closed hi-hat 8ths, firm snare 2/4, punchy kick 1/3. Stop and grade honestly if cymbal wash, buried backbeat, or tempo change appears.',
      'Bars 1–4 VERSE: controlled hats with clear but restrained kick/snare. Bars 5–8 CHORUS: lift kick/snare intent while hats remain underneath. Keep exactly the same 1-&-2-&-3-&-4-& pulse from Bar 1 through Bar 8.',
    ];

    const grooveToFillPurposes = [
      'Map the exact handoff: preserve the 8th-note groove through 3-& and let the first fill stroke replace the hi-hat exactly on Beat 4.',
      'Internalize the mixed grid “1 & 2 & 3 & 4 e & a” without changing the quarter-note pulse when Beat 4 opens into 16ths.',
      'Hear whether the groove survives the transition: 3-& must feel complete and Beat 4 must arrive without a gap, pickup or anticipatory rush.',
      'Follow repeated groove-to-fill cycles with reduced tutor support while keeping the right-hand move from hi-hat to snare relaxed and on time.',
      'Enter the Beat-4 fill independently for repeated bars with metronome only. The groove before every fill must remain as stable as the fill itself.',
      'Repeat the transition as a controlled phrase study so every entry sounds intentional, even and musically connected rather than like a separate exercise pasted onto the groove.',
    ];
    const grooveToFillInstructions = [
      'Play Kick + closed hi-hat on 1, hi-hat on &, Snare + hi-hat on 2, hi-hat on &, Kick + hi-hat on 3, hi-hat on 3-&. From that final hi-hat, move directly to Snare R-L-R-L on 4-e-&-a.',
      'Count aloud “1 & 2 & 3 & 4 e & a”. Do not insert silent e/a syllables into Beats 1–3 and do not make Beat 4 faster; only the note density changes.',
      'Listen specifically to the seam between 3-& and 4. A clean model has no missing 3-&, no extra pickup and no change in click spacing as the snare fill begins.',
      'Use Reduced Follow. Copy one complete tutor cycle, then reproduce the same 3-& → 4 handoff in your response space. Keep the hi-hat present until the final upbeat.',
      `Metronome only. Complete ${competency.durationCriterion}. If the groove shortens before Beat 4 or the fill pulls ahead of the click, stop and grade the run honestly.`,
      'Treat each governed bar as one complete transition cycle. Keep the groove relaxed through Beats 1–3, make one decisive handoff on Beat 4, and preserve the same pulse and sound quality from the first cycle to the last.',
    ];
    const grooveToFillMissionLabels = [
      'Map the Handoff',
      'Count the Handoff',
      'Hear the Seam',
      'Follow the Transition',
      'Enter the Fill Alone',
      'Repeat It Musically',
    ];

    const purpose = isFullSongPerformance
      ? performancePurposes[index]
      : isReading
      ? readingPurposes[index]
      : isMusicalBalance
        ? musicalBalancePurposes[index]
      : isGrooveToFillEntry
        ? grooveToFillPurposes[index]
      : isRudimentApplication && rudimentApplicationPlan
        ? rudimentApplicationPlan.purpose
      : isGrooveSongTransfer
        ? 'Serve a complete 16-bar Verse → Chorus → Verse → Chorus form by changing dynamics without changing tempo or pocket.'
      : n === 1
        ? pedagogy.conceptualFocus
        : n === 2
          ? `Internalize the count: ${competency.countingPattern}.`
          : n === 3
            ? pedagogy.listeningFocus
            : n === 4
              ? `Execute ${competency.title} with reduced tutor dependence.`
              : n === 5
                ? `Demonstrate ${competency.title} without tutor performance.`
                : pedagogy.musicalTransfer;
    const instructions = isFullSongPerformance
      ? performanceInstructions[index]
      : isReading
      ? readingInstructions[index]
      : isMusicalBalance
        ? musicalBalanceInstructions[index]
      : isGrooveToFillEntry
        ? grooveToFillInstructions[index]
      : isRudimentApplication && rudimentApplicationPlan
        ? rudimentApplicationPlan.instructions
      : isGrooveSongTransfer
        ? `Metronome only. Play the full 16-bar form: Bars 1–4 VERSE (controlled), 5–8 CHORUS (lift), 9–12 VERSE RETURN (settle), 13–16 FINAL CHORUS (lift again). Keep the exact same groove and tempo throughout; only the musical energy changes. ${competency.musicalApplicationRequirement}.`
      : n === 1
        ? `${competency.description} Work below verification tempo and prioritize understanding over speed.`
        : n === 2
          ? `Count ${competency.countingPattern} aloud while executing ${competency.stickingPattern}. Keep the pulse relaxed.`
          : n === 3
            ? `Listen to the coach model and identify: ${pedagogy.listeningFocus}`
            : n === 4
              ? `Follow the required pattern with reduced cues. Pattern: ${competency.stickingPattern}. Do not increase tempo if control changes.`
              : n === 5
                ? `Metronome only. Sustain the target pattern for ${competency.durationCriterion}. Stop and grade honestly if timing or mechanics break down.`
                : `${competency.musicalApplicationRequirement}. ${pedagogy.musicalTransfer}`;

    const metadata: CurriculumMissionMetadata = {
      competencyId: competency.id,
      missionId: `c7-${competency.id}-m${n}`,
      missionNumber: n,
      missionTitle: `Mission ${n} — ${isGrooveToFillEntry ? grooveToFillMissionLabels[index] : pedagogy.missionLabels[index]}`,
      stage: stages[index],
      assistanceTarget: assistance[index],
      conceptualTarget: n <= 3,
      executionTarget: n >= 2,
      musicalApplication: musical,
      applicationKind: isRudimentApplication ? 'RUDIMENT_ORCHESTRATION' : undefined,
      applicationEvidenceVersion: isRudimentApplication
        ? C9_RUDIMENT_APPLICATION_EVIDENCE_VERSION
        : undefined,
      performanceTrackId: isFullSongPerformance ? 'pa-canonical-performance-80' : undefined,
      performanceMode: isFullSongPerformance
        ? n >= 6 ? 'MUSICAL_FULL_SONG' : n >= 5 ? 'INDEPENDENT_FULL_SONG' : 'GUIDED_FORM'
        : undefined,
      patternDisplay: pedagogy.patternDisplay,
      requiredPatternLabel: isRudimentApplication && rudimentApplicationPlan
        ? rudimentApplicationPlan.requiredPatternLabel
        : pedagogy.patternDisplay === 'NONE' || pedagogy.patternDisplay === 'BAR_STRUCTURE' || pedagogy.patternDisplay === 'NOTATION'
        ? undefined
        : competency.stickingPattern,
      pedagogyDomain: pedagogy.domain,
      structure: isRudimentApplication
        ? {
            totalBars: 5,
            phraseGroupSize: 1,
            beatsPerBar: 4,
            highlightLandmarkBars: [1, 4, 5],
            showBarNumbers: true,
            showBeatNumbers: true,
            sections: [
              { label: 'GROOVE', startBar: 1, bars: 3, intensity: 'MEDIUM' as const, performanceCue: 'Settle the pocket. Do not prepare early for the fill.' },
              { label: 'HANDOFF + FILL', startBar: 4, bars: 1, intensity: 'STRONG' as const, performanceCue: 'Keep Beats 1–2 in the groove, then preserve the rudiment exactly on Beats 3–4.' },
              { label: 'LAND + RECOVER', startBar: 5, bars: 1, intensity: 'MEDIUM' as const, performanceCue: 'Crash + Kick on Beat 1, then recover the original groove immediately.' },
            ],
          }
        : c7StructureFor(competency, bars[index], pedagogy.domain, n),
    };

    return {
      id: `${sessionId}-m${n}`,
      title: metadata.missionTitle,
      phase: n === 1 ? 'FOUNDATION' : musical ? 'APPLICATION' : 'MAIN WORK',
      skillIds: [competency.skillId],
      purpose,
      whyThisExercise: purpose,
      pedagogicalRole: independent ? 'INDEPENDENCE TEST' : n === 1 ? 'PREPARATION' : 'PRIMARY TARGET',
      instructions,
      sticking: isRudimentApplication && rudimentApplicationPlan
        ? rudimentApplicationPlan.requiredPatternLabel
        : pedagogy.patternDisplay === 'NONE' || pedagogy.patternDisplay === 'BAR_STRUCTURE' || pedagogy.patternDisplay === 'NOTATION'
        ? undefined
        : competency.stickingPattern,
      counting: competency.countingPattern,
      timeSignature: c7TimeSignature(competency),
      subdivision: competency.subdivision,
      tempo: bpm,
      targetTempo: target,
      durationSeconds: isFullSongPerformance
        ? [60, 90, 120, 120, 180, 180][index]
        : n <= 2 ? 45 : n <= 4 ? 60 : 90,
      exerciseType: c7ExerciseType(pedagogy.domain, musical),
      equipmentRequired: isRudimentApplication ? 'Either' : equipment,
      difficulty: independent || musical ? 'Challenging' : n >= 3 ? 'Moderate' : 'Easy',
      curriculumMission: metadata,
      progressionStage: musical ? 'TRANSFER' : n >= 3 ? 'APPLICATION' : 'FOUNDATION',
      challengeType: isRudimentApplication ? 'kit-orchestration' : isFullSongPerformance ? 'sustained-endurance' : musical ? 'groove-phrase' : 'precision-mechanics',
      transferInstructions: isRudimentApplication && rudimentApplicationPlan
        ? {
            baseSticking: competency.stickingPattern,
            accentPattern: 'Preserve the authored accents while changing only the surface assignment.',
            orchestrationMap: [
              { zone: 'Groove', notes: 'Bars 1–3', instruction: 'Keep kick/snare/closed-hi-hat pocket stable.' },
              { zone: 'Handoff + Rudiment Fill', notes: 'Bar 4: groove on Beats 1–2; rudiment fill on Beats 3–4', instruction: 'Keep the original sticking; move only the fill surfaces.' },
              { zone: 'Landing + Recovery', notes: 'Bar 5 Beat 1 → rest of Bar 5', instruction: 'Crash + Kick together on 1, then recover the groove immediately.' },
            ],
            musicalCounting: 'Bars 1–3: 1 & 2 & 3 & 4 & · Bar 4: 1 & 2 & 3 e & a 4 e & a · Bar 5: 1 & 2 & 3 & 4 &',
            executionTarget: rudimentApplicationPlan.listeningTarget,
          }
        : undefined,
      sessionSource: 'C7_CANONICAL_COMPETENCY',
      skillId: competency.skillId,
    };
  });

  return {
    id: sessionId,
    date: new Date().toISOString().slice(0, 10),
    durationMinutes: placementBand === 'BEGINNER' ? 18 : 14,
    practiceContext: profile.practicePriority === 'Song / Performance Preparation' ? 'SONG_SERVICE_PREP' : profile.practicePriority === 'Balanced' ? 'BALANCED' : 'SKILL_DEVELOPMENT',
    equipment: profile.equipment === 'Practice Pad' ? 'Practice Pad' : 'Full Drum Kit',
    focusMode: 'COACH_CHOOSES',
    selectedSkillIds: [competency.skillId],
    skillId: competency.skillId,
    focusTopic: `${competency.title} — C7 ${pedagogy.domain.replace(/_/g, ' ')} Journey`,
    notes: `${placementBand} placement adjusts teaching depth and starting tempo only. ${pedagogy.domain} pedagogy and evidence remain competency-specific.`,
    rating: 5,
    exercises,
    sessionStatus: 'NOT_STARTED',
    sessionSource: 'C7_CANONICAL_COMPETENCY',
    curriculumPractice: {
      competencyId: competency.id,
      placementBand,
      journeyVersion: 'C7',
      missionCount: exercises.length,
      personalizedDepth: depth,
    },
  };
}


/**
 * C7.13 — Groove Stability long-form integrity continuation.
 *
 * The learner may already have completed Missions 1–4 before the transport
 * length / song-form correction landed. Preserve those valid conceptual,
 * listening and reduced-guidance records. Only Mission 5 (real 16-bar
 * independent endurance) and Mission 6 (real 16-bar section-aware transfer)
 * need to be repeated on the corrected transport.
 */
export function needsC7GrooveIntegrityContinuation(competencyId: string): boolean {
  if (competencyId !== 'comp-grv-stability') return false;
  const records = getCurriculumEvidenceRecords(competencyId);
  const success = (record: CurriculumMissionEvidenceRecord) =>
    record.assessment === 'CLEAN_AND_RELAXED' || record.assessment === 'MOSTLY_CLEAN';
  const hasMission = (missionNumber: number) =>
    records.some((record) => record.missionNumber === missionNumber && success(record));
  const earlierJourneyComplete = [1, 2, 3, 4].every(hasMission);
  const correctedLongFormComplete = [5, 6].every(hasMission);
  return earlierJourneyComplete && !correctedLongFormComplete;
}

export function buildC7GrooveIntegrityContinuationSession(
  competency: CurriculumCompetency,
  profile: LearnerProfile,
  placementBand: CurriculumBand
): PracticeSession {
  const fullSession = buildC7CompetencySession(competency, profile, placementBand);
  const records = getCurriculumEvidenceRecords(competency.id);
  const success = (record: CurriculumMissionEvidenceRecord) =>
    record.assessment === 'CLEAN_AND_RELAXED' || record.assessment === 'MOSTLY_CLEAN';
  const hasMission = (missionNumber: number) =>
    records.some((record) => record.missionNumber === missionNumber && success(record));
  const missingMissionNumbers = [5, 6].filter((missionNumber) => !hasMission(missionNumber));
  const sessionId = `c7-13-groove-integrity-${competency.id}-${Date.now()}`;
  const exercises = fullSession.exercises
    .filter((exercise) => missingMissionNumbers.includes(exercise.curriculumMission?.missionNumber || 0))
    .map((exercise) => ({
      ...exercise,
      id: `${sessionId}-m${exercise.curriculumMission?.missionNumber || 0}`,
    }));

  return {
    ...fullSession,
    id: sessionId,
    durationMinutes: exercises.length <= 1 ? 8 : 14,
    focusTopic: `${competency.title} — Corrected Long-Form Continuation`,
    notes: 'C7.13 integrity continuation: Missions 1–4 remain banked. Complete only the missing corrected 16-bar independent/song-form work; prior learning evidence is preserved.',
    exercises,
    curriculumPractice: {
      ...fullSession.curriculumPractice!,
      missionCount: exercises.length,
    },
  };
}

/**
 * C9 — Targeted rudiment musical-application repair.
 *
 * C9 rebases the application mission onto the corrected C8 baseline, but gives the
 * transfer exercise a real five-bar phrase, explicit Crash+Kick landing, immediate
 * recovery bar, and an evidence version that cannot be inferred from older generic
 * attempts. The continuation asks only for Mission 6 and preserves technical work.
 */
export function buildC9RudimentMusicalApplicationSession(
  competency: CurriculumCompetency,
  profile: LearnerProfile,
  placementBand: CurriculumBand
): PracticeSession {
  const fullSession = buildC7CompetencySession(competency, profile, placementBand);
  const applicationExercises = (fullSession.exercises || [])
    .filter((exercise) =>
      exercise.curriculumMission?.stage === 'MUSICAL_APPLICATION' &&
      exercise.curriculumMission?.applicationKind === 'RUDIMENT_ORCHESTRATION'
    )
    .map((exercise) => ({
      ...exercise,
      durationSeconds: Math.max(90, exercise.durationSeconds || 90),
    }));

  if (applicationExercises.length === 0) return fullSession;

  return {
    ...fullSession,
    id: `c9-rudiment-application-${competency.id}-${Date.now()}`,
    durationMinutes: 8,
    focusTopic: `${competency.title} — Musical Application`,
    notes: 'C9 targeted transfer: prior technical learning is preserved. Complete only the corrected five-bar groove → rudiment fill → Crash+Kick landing → immediate groove recovery application.',
    // Keep the canonical c7-...-m6 exercise id so the fallback evidence
    // reconstruction path can still recover this run if the dedicated ledger
    // write is ever interrupted. The session id itself marks this as C9 repair.
    exercises: applicationExercises,
    curriculumPractice: fullSession.curriculumPractice
      ? { ...fullSession.curriculumPractice, missionCount: applicationExercises.length }
      : undefined,
  };
}


/**
 * C7.9 — Targeted second-session revisit.
 *
 * When the learner has already evidenced every learning dimension except the
 * required separate-session revisit, repeating the full teaching journey is
 * unnecessary. This creates a fresh governed session containing only the
 * independent and musical-transfer missions. A clean independent result in
 * this new session can simultaneously satisfy C7's separate-session coverage
 * and C4's separate qualifying independent-session requirement.
 */
export function buildC7SecondSessionRevisitSession(
  competency: CurriculumCompetency,
  profile: LearnerProfile,
  placementBand: CurriculumBand
): PracticeSession {
  const fullSession = buildC7CompetencySession(competency, profile, placementBand);
  const revisitExercises = (fullSession.exercises || [])
    .filter((exercise) => {
      const assistance = exercise.curriculumMission?.assistanceTarget;
      return assistance === 'NONE' || assistance === 'MINIMAL';
    })
    .map((exercise) => ({
      ...exercise,
      tempo: competency.tempoStandard.bpm,
      targetTempo: competency.tempoStandard.bpm,
      durationSeconds: Math.max(60, exercise.durationSeconds || 60),
    }));

  if (revisitExercises.length === 0) return fullSession;

  return {
    ...fullSession,
    durationMinutes: Math.max(6, revisitExercises.length * 4),
    focusTopic: `${competency.title} — Separate-Session Revisit`,
    notes: `C7.9 targeted revisit: prior learning evidence is preserved. This fresh session repeats only genuine independent and musical-transfer work so separate-session evidence can be earned without redoing the full teaching journey.`,
    exercises: revisitExercises,
    curriculumPractice: fullSession.curriculumPractice
      ? { ...fullSession.curriculumPractice, missionCount: revisitExercises.length }
      : undefined,
  };
}

/**
 * C7.7 — Short verification-stabilization session.
 *
 * Once the learner has already covered all six curriculum evidence dimensions,
 * repeating the whole teaching journey is wasteful and can encourage stage
 * bypassing. This continuation keeps only the canonical no-assistance missions
 * (independent execution + musical transfer) and runs them at the formal target
 * tempo, creating a fresh session boundary for C4's separate-session criterion.
 */
export function buildC7VerificationStabilizationSession(
  competency: CurriculumCompetency,
  profile: LearnerProfile,
  placementBand: CurriculumBand
): PracticeSession {
  const fullSession = buildC7CompetencySession(competency, profile, placementBand);
  const independentExercises = (fullSession.exercises || [])
    .filter((exercise) => {
      const assistance = exercise.curriculumMission?.assistanceTarget;
      return assistance === 'NONE' || assistance === 'MINIMAL';
    })
    .map((exercise) => ({
      ...exercise,
      tempo: competency.tempoStandard.bpm,
      targetTempo: competency.tempoStandard.bpm,
      durationSeconds: Math.max(60, exercise.durationSeconds || 60),
    }));

  // Defensive fallback: if a future competency journey has no explicit NONE /
  // MINIMAL stage, preserve the original session rather than returning an empty one.
  if (independentExercises.length === 0) return fullSession;

  return {
    ...fullSession,
    durationMinutes: Math.max(6, independentExercises.length * 4),
    focusTopic: `${competency.title} — Verification Stabilization`,
    notes: `C7.7 targeted continuation: curriculum coverage is already complete, so this session repeats only genuine independent and musical-transfer evidence at the formal standard.`,
    exercises: independentExercises,
    curriculumPractice: fullSession.curriculumPractice
      ? { ...fullSession.curriculumPractice, missionCount: independentExercises.length }
      : undefined,
  };
}



/**
 * C7.11 — Protocol revalidation session for competencies whose historical C4
 * checkpoint was invalidated by verifier-v2.
 *
 * These learners already completed the older competency journey. We preserve
 * that history and ask only for fresh no-assistance evidence on the corrected
 * clock before exposing the new formal verification. This prevents a protocol
 * migration from forcing a full six-mission relearn.
 */
export function buildC7ProtocolRevalidationSession(
  competency: CurriculumCompetency,
  profile: LearnerProfile,
  placementBand: CurriculumBand,
  workingBpm?: number | null
): PracticeSession {
  const fullSession = buildC7CompetencySession(competency, profile, placementBand);
  const target = competency.tempoStandard.bpm;
  const safeBpm = Math.max(
    30,
    Math.min(target, workingBpm && Number.isFinite(workingBpm) ? Math.round(workingBpm) : Math.round(target * 0.9))
  );

  const independentExercises = (fullSession.exercises || [])
    .filter((exercise) => {
      const assistance = exercise.curriculumMission?.assistanceTarget;
      return assistance === 'NONE' || assistance === 'MINIMAL';
    })
    .map((exercise) => ({
      ...exercise,
      tempo: safeBpm,
      targetTempo: target,
      durationSeconds: Math.max(60, exercise.durationSeconds || 60),
    }));

  if (independentExercises.length === 0) return fullSession;

  return {
    ...fullSession,
    durationMinutes: Math.max(6, independentExercises.length * 4),
    focusTopic: `${competency.title} — Corrected-Clock Revalidation`,
    notes: `C7.11 protocol migration: earlier learning and practice history are preserved. The old formal checkpoint used the pre-v2 verifier, so this short session collects fresh no-assistance evidence on the corrected clock without repeating the full curriculum journey.`,
    exercises: independentExercises,
    curriculumPractice: fullSession.curriculumPractice
      ? { ...fullSession.curriculumPractice, missionCount: independentExercises.length }
      : undefined,
  };
}

/**
 * C7.12 — Targeted formal-verification repair.
 *
 * A failed formal C4 verification must not restart the six-mission curriculum
 * journey when the learner already has complete C7 coverage. This repair keeps
 * only the genuine no-assistance end stages, lowers the tempo into the readiness
 * neighbourhood, and marks the exercises as remediation evidence so the active
 * verification repair plan can be cleared by successful work.
 */
export function buildC7VerificationRepairSession(
  competency: CurriculumCompetency,
  profile: LearnerProfile,
  placementBand: CurriculumBand,
  workingBpm?: number | null
): PracticeSession {
  const fullSession = buildC7CompetencySession(competency, profile, placementBand);
  const target = competency.tempoStandard.bpm;
  const readinessFloor = Math.max(30, Math.round(target * 0.85));
  const defaultRepairBpm = Math.max(readinessFloor, Math.round(target * 0.9));
  const observedWorkingBpm = workingBpm && Number.isFinite(workingBpm)
    ? Math.round(workingBpm)
    : defaultRepairBpm;
  const repairBpm = Math.max(
    readinessFloor,
    Math.min(defaultRepairBpm, observedWorkingBpm)
  );

  const repairExercises = (fullSession.exercises || [])
    .filter((exercise) => {
      const assistance = exercise.curriculumMission?.assistanceTarget;
      return assistance === 'NONE' || assistance === 'MINIMAL';
    })
    .map((exercise) => ({
      ...exercise,
      tempo: repairBpm,
      targetTempo: target,
      durationSeconds: Math.max(60, exercise.durationSeconds || 60),
      isGapClosure: true,
      countsTowardRemediation: true,
      sessionSource: 'gap-closure',
      gapClosureReason: 'Targeted repair after a formal verification attempt did not pass.',
      gapClosureSuccessTarget: `Complete this no-assistance run Clean & Relaxed at ${repairBpm} BPM before retesting.`,
    }));

  if (repairExercises.length === 0) return fullSession;

  return {
    ...fullSession,
    durationMinutes: Math.max(6, repairExercises.length * 4),
    focusTopic: `${competency.title} — Verification Repair`,
    notes: `C7.12 targeted repair: the curriculum journey is already complete. This session repeats only genuine no-assistance evidence at a relaxed near-target tempo before the next formal verification attempt.`,
    exercises: repairExercises,
    sessionStatus: 'NOT_STARTED',
    sessionSource: 'gap-closure',
    isGapClosure: true,
    curriculumPractice: fullSession.curriculumPractice
      ? { ...fullSession.curriculumPractice, missionCount: repairExercises.length }
      : undefined,
  };
}

