export type PlayAlongMeter = '4/4' | '6/8';
export type PlayAlongCoachMode = 'GUIDED' | 'REDUCED' | 'PERFORMANCE';
export type PlayAlongApplicationMode =
  | 'GROOVE_ONLY'
  | 'GROOVE_VARIATION'
  | 'THREE_PLUS_ONE'
  | 'SEVEN_PLUS_ONE'
  | 'HALF_BAR_FILL'
  | 'BEAT_FOUR_FILL'
  | 'RUDIMENT_FILL'
  | 'MUSICAL_CHOICE'
  | 'CREATIVITY_CHALLENGE'
  | 'FULL_ARRANGEMENT'
  | 'FREE_PLAY';

export type SectionCue = 'NO_FILL' | 'SHORT_FILL' | 'BUILD' | 'CRASH_ONLY' | 'FREE';

export interface PlayAlongSection {
  id: string;
  name: string;
  bars: number;
  energy: 1 | 2 | 3 | 4;
  chordProgression: string[];
  grooveHint: string;
  transitionCue: SectionCue;
  coachingNote: string;
  /** C11 optional authored tutor-drum part. Positions use musical beat numbers (1-based; .5 = offbeat). */
  drumGuide?: {
    label: string;
    timekeeper: 'CLOSED_HAT_8THS' | 'OPEN_HAT_8THS' | 'RIDE_QUARTERS' | 'RIDE_8THS';
    kickPositions: number[];
    snarePositions: number[];
    entryCrash?: boolean;
    exitFill?: 'NONE' | 'BEAT_4_EIGHTHS' | 'BEAT_4_SIXTEENTHS' | 'TWO_BEAT_BUILD';
  };
}

export interface PlayAlongVariation {
  id: string;
  label: string;
  description: string;
  prerequisiteCompetencyIds: string[];
  kind: 'groove' | 'fill' | 'rudiment' | 'dynamic' | 'restraint';
  countPattern?: string;
  stickingPattern?: string;
  placementHint?: string;
}

export interface PlayAlongTrack {
  id: string;
  title: string;
  subtitle: string;
  style: string;
  meter: PlayAlongMeter;
  bpm: number;
  key: string;
  difficulty: 'Beginner' | 'Intermediate';
  targetCompetencyIds: string[];
  recommendedForCompetencyIds: string[];
  whyUseIt: string;
  sections: PlayAlongSection[];
  variations: PlayAlongVariation[];
}

export const PLAY_ALONG_TRACKS: PlayAlongTrack[] = [
  {
    id: 'pa-slow-ballad-64',
    title: 'Slow 4/4 Ballad',
    subtitle: 'Pulse, backbeat, restraint & Beat-1 confidence',
    style: 'Ballad / Pop',
    meter: '4/4',
    bpm: 64,
    key: 'G',
    difficulty: 'Beginner',
    targetCompetencyIds: ['comp-pulse-quarter', 'comp-subdiv-8th', 'comp-meter-44'],
    recommendedForCompetencyIds: [
      'comp-pulse-quarter',
      'comp-subdiv-8th',
      'comp-meter-44',
      'comp-reading-notation',
    ],
    whyUseIt: 'A spacious no-drum musical bed that exposes rushing and dragging. Ideal before the drummer adds a full groove.',
    sections: [
      {
        id: 'intro', name: 'Intro', bars: 4, energy: 1,
        chordProgression: ['G', 'D', 'Em', 'C'],
        grooveHint: 'Quarter-note pulse only. Feel four equal beats.',
        transitionCue: 'NO_FILL',
        coachingNote: 'Do not decorate the intro. Let the pulse settle first.',
      },
      {
        id: 'verse', name: 'Verse', bars: 8, energy: 1,
        chordProgression: ['G', 'D', 'Em', 'C'],
        grooveHint: 'Keep the pulse steady; add a soft backbeat only if already verified.',
        transitionCue: 'NO_FILL',
        coachingNote: 'Restraint is the lesson here. Stay under the imagined vocal.',
      },
      {
        id: 'chorus', name: 'Chorus', bars: 8, energy: 2,
        chordProgression: ['C', 'G', 'D', 'Em'],
        grooveHint: 'Slightly stronger pulse. Keep tempo identical while energy rises.',
        transitionCue: 'CRASH_ONLY',
        coachingNote: 'Lift the section with dynamics, not extra notes.',
      },
      {
        id: 'outro', name: 'Outro', bars: 4, energy: 1,
        chordProgression: ['G', 'D', 'C', 'G'],
        grooveHint: 'Return to simple pulse and finish calmly.',
        transitionCue: 'NO_FILL',
        coachingNote: 'End with control. Do not rush the final two bars.',
      },
    ],
    variations: [
      {
        id: 'pulse-only', label: 'Quarter-note pulse',
        description: 'Play one relaxed stroke per beat and make the click disappear beneath your stroke.',
        prerequisiteCompetencyIds: [], kind: 'groove',
        countPattern: '1 - 2 - 3 - 4',
        stickingPattern: 'R R R R (or alternate hands if the current lesson asks for it)',
        placementHint: 'Stay simple through the whole arrangement; the musical challenge is consistency, not vocabulary.',
      },
      {
        id: '8th-count', label: 'Count eighths internally',
        description: 'Keep playing quarter notes while internally hearing 1 & 2 & 3 & 4 &.',
        prerequisiteCompetencyIds: ['comp-subdiv-8th'], kind: 'groove',
        countPattern: '1 & 2 & 3 & 4 &',
        stickingPattern: 'Play on the numbers; hear the & subdivisions internally.',
        placementHint: 'Use the hidden eighth-note grid to stop quarter notes from drifting between beats.',
      },
      {
        id: 'no-fill', label: 'Choose no fill',
        description: 'Cross a section boundary without filling; use a controlled dynamic change instead.',
        prerequisiteCompetencyIds: [], kind: 'restraint',
        placementHint: 'Listen to the harmony and let the section change be the event. A clean no-fill is an intentional choice.',
      },
    ],
  },
  {
    id: 'pa-worship-ballad-68',
    title: '4/4 Worship Ballad',
    subtitle: 'Groove → transition → chorus lift',
    style: 'Worship',
    meter: '4/4',
    bpm: 68,
    key: 'D',
    difficulty: 'Beginner',
    targetCompetencyIds: [
      'comp-grv-backbeat',
      'comp-grv-stability',
      'comp-grv-kick-variation',
      'comp-dyn-song-balance',
      'comp-fill-entry',
      'comp-fill-recovery',
    ],
    recommendedForCompetencyIds: [
      'comp-grv-backbeat',
      'comp-grv-stability',
      'comp-grv-kick-variation',
      'comp-dyn-song-balance',
      'comp-fill-quarter',
      'comp-fill-8th',
      'comp-fill-entry',
      'comp-fill-recovery',
      'comp-perf-song-app',
    ],
    whyUseIt: 'A church-style arrangement for learning how to preserve pocket while verses, choruses and transitions change around you.',
    sections: [
      {
        id: 'intro', name: 'Intro', bars: 4, energy: 1,
        chordProgression: ['D', 'A', 'Bm', 'G'],
        grooveHint: 'Simple pulse or soft 8th-note groove.',
        transitionCue: 'NO_FILL',
        coachingNote: 'Let the song establish itself before adding vocabulary.',
      },
      {
        id: 'verse', name: 'Verse', bars: 8, energy: 1,
        chordProgression: ['D', 'A', 'Bm', 'G'],
        grooveHint: 'Closed hats, steady backbeat, simple kick placement.',
        transitionCue: 'SHORT_FILL',
        coachingNote: 'Keep the imagined vocal clear. One short transition is enough.',
      },
      {
        id: 'chorus', name: 'Chorus', bars: 8, energy: 3,
        chordProgression: ['G', 'D', 'A', 'Bm'],
        grooveHint: 'Open the cymbal texture slightly; keep the same pocket.',
        transitionCue: 'CRASH_ONLY',
        coachingNote: 'Energy rises, but the tempo must not.',
      },
      {
        id: 'bridge', name: 'Bridge Build', bars: 8, energy: 2,
        chordProgression: ['Bm', 'G', 'D', 'A'],
        grooveHint: 'Build gradually across the section instead of peaking in bar 1.',
        transitionCue: 'BUILD',
        coachingNote: 'Think long-range dynamics: low → medium → strong.',
      },
      {
        id: 'final', name: 'Final Chorus', bars: 8, energy: 4,
        chordProgression: ['G', 'D', 'A', 'Bm'],
        grooveHint: 'Strongest version of the groove; preserve clean 2 & 4.',
        transitionCue: 'FREE',
        coachingNote: 'Use only vocabulary you can execute without disturbing the song.',
      },
      {
        id: 'outro', name: 'Outro', bars: 4, energy: 1,
        chordProgression: ['G', 'A', 'D', 'D'],
        grooveHint: 'Reduce density and finish together with the band.',
        transitionCue: 'NO_FILL',
        coachingNote: 'Musical maturity includes knowing how to come down.',
      },
    ],
    variations: [
      {
        id: 'base-groove', label: 'Basic backbeat groove',
        description: '8th-note hats, snare on 2 & 4, simple kick on 1 and 3.',
        prerequisiteCompetencyIds: ['comp-grv-backbeat', 'comp-grv-stability'], kind: 'groove',
        countPattern: '1 & 2 & 3 & 4 &',
        stickingPattern: 'HH: x x x x x x x x • S: 2, 4 • K: 1, 3',
        placementHint: 'Use as the default verse groove.',
      },
      {
        id: 'kick-var', label: 'Kick variation',
        description: 'Add the verified 3-and kick while keeping the backbeat and hi-hat unchanged.',
        prerequisiteCompetencyIds: ['comp-grv-kick-variation'], kind: 'groove',
        countPattern: '1 & 2 & 3 & 4 &',
        stickingPattern: 'HH stays constant • S: 2, 4 • K: 1, 3, 3&',
        placementHint: 'Introduce after the basic groove is settled; do not change the snare placement.',
      },
      {
        id: 'quarter-fill', label: 'Quarter-note transition fill',
        description: 'Use four deliberate notes in the final bar and land beat 1 confidently.',
        prerequisiteCompetencyIds: ['comp-fill-quarter', 'comp-fill-recovery'], kind: 'fill',
        countPattern: '1 - 2 - 3 - 4 -> CRASH 1',
        stickingPattern: 'R L R L across snare / toms',
        placementHint: 'Use on a major section ending, not every four bars.',
      },
      {
        id: '8th-fill', label: 'Eighth-note transition fill',
        description: 'Move even 8ths around the kit without squeezing the final note before beat 1.',
        prerequisiteCompetencyIds: ['comp-fill-8th', 'comp-fill-recovery'], kind: 'fill',
        countPattern: '1 & 2 & 3 & 4 & -> CRASH 1',
        stickingPattern: 'R L R L R L R L, moving gradually around the kit',
        placementHint: 'Use when the arrangement needs more lift than a quarter-note fill.',
      },
      {
        id: '16th-fill', label: 'Sixteenth-note transition burst',
        description: 'Use a short, even sixteenth-note burst without turning the whole transition into a speed test.',
        prerequisiteCompetencyIds: ['comp-fill-16th', 'comp-fill-recovery'], kind: 'fill',
        countPattern: '3 e & a 4 e & a -> CRASH 1',
        stickingPattern: 'R L R L R L R L across snare / toms',
        placementHint: 'Begin with the final half bar. Keep the subdivision relaxed and leave space before it.',
      },
      {
        id: 'single-stroke-fill', label: 'Single-stroke musical fill',
        description: 'Use even alternating singles as a short musical fill while preserving the phrase.',
        prerequisiteCompetencyIds: ['comp-rud-singles', 'comp-fill-recovery'], kind: 'rudiment',
        countPattern: '1 e & a 2 e & a 3 e & a 4 e & a',
        stickingPattern: 'R L R L…; orchestrate simply from snare to toms',
        placementHint: 'Start with half a bar before attempting a full-bar stream.',
      },
      {
        id: 'double-stroke-fill', label: 'Double-stroke musical fill',
        description: 'Use R R L L groups as a controlled fill rather than a pad-only roll.',
        prerequisiteCompetencyIds: ['comp-rud-doubles', 'comp-fill-recovery'], kind: 'rudiment',
        countPattern: '1 e & a 2 e & a…',
        stickingPattern: 'R R L L R R L L',
        placementHint: 'Keep doubles relaxed; move only after the rebound remains even.',
      },
      {
        id: 'paradiddle-fill', label: 'Paradiddle phrase fill',
        description: 'Turn R L R R L R L L into a phrase-ending fill with clear accents and a clean Beat-1 return.',
        prerequisiteCompetencyIds: ['comp-rud-single-paradiddle', 'comp-fill-recovery'], kind: 'rudiment',
        countPattern: '1 e & a 2 e & a',
        stickingPattern: '>R L R R >L R L L',
        placementHint: 'Try snare for taps, toms for accents; keep the sticking intact.',
      },
      {
        id: 'dynamic-lift', label: 'Dynamic lift',
        description: 'Raise energy with cymbal texture and stroke height rather than a busier groove.',
        prerequisiteCompetencyIds: ['comp-dyn-song-balance'], kind: 'dynamic',
        placementHint: 'Use section energy changes before reaching for extra notes.',
      },
      {
        id: 'no-fill', label: 'Deliberate no-fill transition',
        description: 'Cross a section boundary with a dynamic change or crash only and leave deliberate space.',
        prerequisiteCompetencyIds: [], kind: 'restraint',
        placementHint: 'Use whenever a fill would compete with the vocal or musical phrase.',
      },
    ],
  },
  {
    id: 'pa-medium-worship-78',
    title: 'Medium 4/4 Worship',
    subtitle: 'Kick variations, builds & phrase-length choices',
    style: 'Worship / Pop Rock',
    meter: '4/4',
    bpm: 78,
    key: 'A',
    difficulty: 'Intermediate',
    targetCompetencyIds: [
      'comp-subdiv-16th',
      'comp-time-syncopation',
      'comp-dyn-build',
      'comp-fill-restraint',
      'comp-perf-song-arrangement-int',
    ],
    recommendedForCompetencyIds: [
      'comp-subdiv-16th',
      'comp-time-syncopation',
      'comp-time-syncopation',
      'comp-dyn-build',
      'comp-fill-restraint',
      'comp-perf-song-arrangement-int',
    ],
    whyUseIt: 'A faster arrangement for choosing fill lengths, handling builds and keeping syncopated kick ideas inside a stable song form.',
    sections: [
      {
        id: 'intro', name: 'Intro', bars: 4, energy: 2,
        chordProgression: ['A', 'E', 'F#m', 'D'],
        grooveHint: 'Solid 8ths; establish the pocket before adding syncopation.',
        transitionCue: 'NO_FILL',
        coachingNote: 'Give the listener the groove before you vary it.',
      },
      {
        id: 'verse', name: 'Verse', bars: 8, energy: 1,
        chordProgression: ['A', 'E', 'F#m', 'D'],
        grooveHint: 'Lower dynamic, selective kick variation.',
        transitionCue: 'SHORT_FILL',
        coachingNote: 'One short fill is more musical than filling every phrase.',
      },
      {
        id: 'pre', name: 'Pre-Chorus', bars: 4, energy: 2,
        chordProgression: ['F#m', 'D', 'A', 'E'],
        grooveHint: 'Gradually open the sound and prepare the chorus.',
        transitionCue: 'BUILD',
        coachingNote: 'Make the last bar feel inevitable, not rushed.',
      },
      {
        id: 'chorus', name: 'Chorus', bars: 8, energy: 4,
        chordProgression: ['D', 'A', 'E', 'F#m'],
        grooveHint: 'Strong backbeat and controlled syncopated kick.',
        transitionCue: 'FREE',
        coachingNote: 'Choose a fill only if it improves the transition.',
      },
      {
        id: 'breakdown', name: 'Breakdown', bars: 4, energy: 1,
        chordProgression: ['F#m', 'D', 'A', 'E'],
        grooveHint: 'Strip the groove down. Space is part of the arrangement.',
        transitionCue: 'NO_FILL',
        coachingNote: 'This is a deliberate no-fill checkpoint.',
      },
      {
        id: 'final', name: 'Final Chorus', bars: 8, energy: 4,
        chordProgression: ['D', 'A', 'E', 'F#m'],
        grooveHint: 'Fullest groove while preserving internal subdivision.',
        transitionCue: 'FREE',
        coachingNote: 'Make creative choices without abandoning the pocket.',
      },
    ],
    variations: [
      {
        id: 'sync-kick', label: 'Syncopated kick option',
        description: 'Choose one offbeat kick placement and repeat it consistently across the phrase.',
        prerequisiteCompetencyIds: ['comp-time-syncopation'], kind: 'groove',
      },
      {
        id: '16th-feel', label: 'Internal 16th grid',
        description: 'Keep the groove sparse while internally counting all 16th subdivisions.',
        prerequisiteCompetencyIds: ['comp-subdiv-16th'], kind: 'groove',
      },
      {
        id: 'restraint', label: 'No-fill decision',
        description: 'Choose one transition where you deliberately play no fill and support the band with dynamics only.',
        prerequisiteCompetencyIds: ['comp-fill-restraint'], kind: 'restraint',
      },
      {
        id: 'build', label: 'Four-bar dynamic build',
        description: 'Increase energy every bar without increasing tempo or note density too quickly.',
        prerequisiteCompetencyIds: ['comp-dyn-build'], kind: 'dynamic',
      },
    ],
  },
  {
    id: 'pa-68-worship-58',
    title: '6/8 Worship Ballad',
    subtitle: 'Two-pulse feel, 6/8 groove & musical fills',
    style: 'Worship / Ballad',
    meter: '6/8',
    bpm: 58,
    key: 'C',
    difficulty: 'Intermediate',
    targetCompetencyIds: ['comp-meter-68', 'comp-subdiv-triplets', 'comp-style-worship-68'],
    recommendedForCompetencyIds: [
      'comp-meter-68',
      'comp-subdiv-triplets',
      'comp-style-worship-68',
      'comp-rud-six-stroke',
    ],
    whyUseIt: 'A slow 6/8 musical bed that reinforces the two large pulses (1 and 4) before adding fills or rudimental vocabulary.',
    sections: [
      {
        id: 'intro', name: 'Intro', bars: 4, energy: 1,
        chordProgression: ['C', 'G', 'Am', 'F'],
        grooveHint: 'Feel 1-2-3 / 4-5-6. Do not flatten all six notes equally.',
        transitionCue: 'NO_FILL',
        coachingNote: 'Lock the two-pulse shape before adding a full groove.',
      },
      {
        id: 'verse', name: 'Verse', bars: 8, energy: 1,
        chordProgression: ['C', 'G', 'Am', 'F'],
        grooveHint: 'Gentle 6/8 groove with clear backbeat on 4.',
        transitionCue: 'SHORT_FILL',
        coachingNote: 'Keep fills inside the 6/8 subdivision rather than switching to 4/4 thinking.',
      },
      {
        id: 'chorus', name: 'Chorus', bars: 8, energy: 3,
        chordProgression: ['F', 'C', 'G', 'Am'],
        grooveHint: 'Open the texture while preserving the two large pulses.',
        transitionCue: 'CRASH_ONLY',
        coachingNote: 'Let beat 4 remain a strong internal landmark.',
      },
      {
        id: 'bridge', name: 'Bridge Build', bars: 8, energy: 2,
        chordProgression: ['Am', 'F', 'C', 'G'],
        grooveHint: 'Build gradually across eight bars.',
        transitionCue: 'BUILD',
        coachingNote: 'Keep counting internally even while dynamics grow.',
      },
      {
        id: 'outro', name: 'Outro', bars: 4, energy: 1,
        chordProgression: ['F', 'G', 'C', 'C'],
        grooveHint: 'Return to simple two-pulse feel.',
        transitionCue: 'NO_FILL',
        coachingNote: 'Finish with space and a confident final landing.',
      },
    ],
    variations: [
      {
        id: 'two-pulse', label: 'Two-pulse 6/8 feel',
        description: 'Emphasize counts 1 and 4 while allowing 2-3 and 5-6 to flow underneath.',
        prerequisiteCompetencyIds: ['comp-meter-68'], kind: 'groove',
      },
      {
        id: '68-groove', label: 'Basic 6/8 worship groove',
        description: 'Keep the cymbal pulse flowing and place the backbeat firmly on count 4.',
        prerequisiteCompetencyIds: ['comp-style-worship-68'], kind: 'groove',
      },
      {
        id: 'sixstroke', label: 'Six-stroke 6/8 application',
        description: 'Use a six-note phrase only if the six-stroke competency is already verified.',
        prerequisiteCompetencyIds: ['comp-rud-six-stroke'], kind: 'fill',
      },
    ],
  },
  {
    id: 'pa-canonical-performance-80',
    title: 'Canonical 4/4 Performance — 3:00',
    subtitle: 'Full-song pocket, section awareness, restraint & recovery',
    style: 'Contemporary / Worship-Pop',
    meter: '4/4',
    bpm: 80,
    key: 'G',
    difficulty: 'Beginner',
    targetCompetencyIds: ['comp-perf-song-app'],
    recommendedForCompetencyIds: ['comp-perf-song-app', 'comp-perf-song-arrangement'],
    whyUseIt: 'A purpose-built 60-bar no-drum backing arrangement. At 80 BPM it lasts exactly 3:00, so practice and formal verification use the same long-form musical demand.',
    sections: [
      {
        id: 'intro', name: 'Intro', bars: 4, energy: 1,
        chordProgression: ['G', 'D', 'Em', 'C'],
        grooveHint: 'Establish a simple pocket. No fill is required.',
        transitionCue: 'NO_FILL',
        coachingNote: 'Settle the pulse first. Do not prove vocabulary in the intro.',
        drumGuide: { label: 'Settled intro pocket', timekeeper: 'CLOSED_HAT_8THS', kickPositions: [1, 3], snarePositions: [2, 4], entryCrash: false, exitFill: 'NONE' },
      },
      {
        id: 'verse-a', name: 'Verse A', bars: 12, energy: 1,
        chordProgression: ['G', 'D', 'Em', 'C'],
        grooveHint: 'Closed hats, clear 2 and 4, restrained kick pattern.',
        transitionCue: 'SHORT_FILL',
        coachingNote: 'Protect the imagined vocal and keep the groove predictable.',
        drumGuide: { label: 'Verse pocket', timekeeper: 'CLOSED_HAT_8THS', kickPositions: [1, 3, 3.5], snarePositions: [2, 4], entryCrash: false, exitFill: 'BEAT_4_EIGHTHS' },
      },
      {
        id: 'chorus-a', name: 'Chorus A', bars: 12, energy: 3,
        chordProgression: ['C', 'G', 'D', 'Em'],
        grooveHint: 'Lift the cymbal texture and backbeat without speeding up.',
        transitionCue: 'CRASH_ONLY',
        coachingNote: 'Energy rises through dynamics, not through rushing.',
        drumGuide: { label: 'Chorus lift', timekeeper: 'OPEN_HAT_8THS', kickPositions: [1, 1.5, 3, 3.5], snarePositions: [2, 4], entryCrash: true, exitFill: 'NONE' },
      },
      {
        id: 'verse-return', name: 'Verse Return', bars: 12, energy: 1,
        chordProgression: ['G', 'D', 'Em', 'C'],
        grooveHint: 'Return to the simpler texture immediately and keep the same internal pulse.',
        transitionCue: 'NO_FILL',
        coachingNote: 'Coming down cleanly is part of arrangement control.',
        drumGuide: { label: 'Verse-return restraint', timekeeper: 'CLOSED_HAT_8THS', kickPositions: [1, 3], snarePositions: [2, 4], entryCrash: false, exitFill: 'NONE' },
      },
      {
        id: 'bridge-build', name: 'Bridge Build', bars: 8, energy: 2,
        chordProgression: ['Em', 'C', 'G', 'D'],
        grooveHint: 'Build gradually across the eight bars while leaving space.',
        transitionCue: 'BUILD',
        coachingNote: 'Do not peak on bar 1. Let the section grow.',
        drumGuide: { label: 'Bridge build', timekeeper: 'RIDE_8THS', kickPositions: [1, 3, 3.5], snarePositions: [2, 4], entryCrash: false, exitFill: 'TWO_BEAT_BUILD' },
      },
      {
        id: 'final-chorus', name: 'Final Chorus', bars: 8, energy: 4,
        chordProgression: ['C', 'G', 'D', 'Em'],
        grooveHint: 'Strongest groove of the song. Preserve the pocket and choose fills sparingly.',
        transitionCue: 'FREE',
        coachingNote: 'Musical confidence means strong time plus controlled choices.',
        drumGuide: { label: 'Final-chorus full pocket', timekeeper: 'OPEN_HAT_8THS', kickPositions: [1, 1.5, 3, 3.5], snarePositions: [2, 4], entryCrash: true, exitFill: 'BEAT_4_SIXTEENTHS' },
      },
      {
        id: 'outro', name: 'Outro', bars: 4, energy: 1,
        chordProgression: ['C', 'D', 'G', 'G'],
        grooveHint: 'Reduce density and finish together with the track.',
        transitionCue: 'NO_FILL',
        coachingNote: 'Recover the simple pocket and finish without rushing the last bar.',
        drumGuide: { label: 'Outro settle', timekeeper: 'CLOSED_HAT_8THS', kickPositions: [1, 3], snarePositions: [2, 4], entryCrash: false, exitFill: 'NONE' },
      },
    ],
    variations: [
      {
        id: 'canonical-pocket', label: 'Canonical pocket',
        description: '8th-note timekeeping, clear backbeat and a simple kick foundation. Keep it stable enough to survive every section.',
        prerequisiteCompetencyIds: ['comp-grv-stability'], kind: 'groove',
        countPattern: '1 & 2 & 3 & 4 &',
        stickingPattern: 'HH: steady 8ths • S: 2, 4 • K: simple stable phrase',
        placementHint: 'This is the default. Do not abandon it just because a section gets louder.',
      },
      {
        id: 'section-lift', label: 'Section lift',
        description: 'Raise energy with cymbal texture and backbeat weight while keeping the tempo unchanged.',
        prerequisiteCompetencyIds: ['comp-dyn-accent-contrast'], kind: 'dynamic',
        placementHint: 'Use in choruses and the bridge build. The pulse must feel identical underneath.',
      },
      {
        id: 'short-transition', label: 'Short transition',
        description: 'Use a compact phrase-ending fill only when the arrangement asks for one, then recover the groove immediately.',
        prerequisiteCompetencyIds: ['comp-fill-recovery'], kind: 'fill',
        placementHint: 'Prefer one short fill over continuous decoration.',
      },
      {
        id: 'deliberate-restraint', label: 'Deliberate restraint',
        description: 'Cross a section boundary with no fill and let harmony/dynamics create the transition.',
        prerequisiteCompetencyIds: [], kind: 'restraint',
        placementHint: 'Use at least once so the test measures musical judgement, not only execution.',
      },
    ],
  },
  {
    id: 'pa-68-worship-58',
    title: '6/8 Worship Ballad',
    subtitle: 'Two-pulse feel, 6/8 groove & musical fills',
    style: 'Worship / Ballad',
    meter: '6/8',
    bpm: 58,
    key: 'C',
    difficulty: 'Intermediate',
    targetCompetencyIds: ['comp-meter-68', 'comp-subdiv-triplets', 'comp-style-worship-68'],
    recommendedForCompetencyIds: [
      'comp-meter-68',
      'comp-subdiv-triplets',
      'comp-style-worship-68',
      'comp-rud-six-stroke',
    ],
    whyUseIt: 'A slow 6/8 musical bed that reinforces the two large pulses (1 and 4) before adding fills or rudimental vocabulary.',
    sections: [
      {
        id: 'intro', name: 'Intro', bars: 4, energy: 1,
        chordProgression: ['C', 'G', 'Am', 'F'],
        grooveHint: 'Feel 1-2-3 / 4-5-6. Do not flatten all six notes equally.',
        transitionCue: 'NO_FILL',
        coachingNote: 'Lock the two-pulse shape before adding a full groove.',
      },
      {
        id: 'verse', name: 'Verse', bars: 8, energy: 1,
        chordProgression: ['C', 'G', 'Am', 'F'],
        grooveHint: 'Gentle 6/8 groove with clear backbeat on 4.',
        transitionCue: 'SHORT_FILL',
        coachingNote: 'Keep fills inside the 6/8 subdivision rather than switching to 4/4 thinking.',
      },
      {
        id: 'chorus', name: 'Chorus', bars: 8, energy: 3,
        chordProgression: ['F', 'C', 'G', 'Am'],
        grooveHint: 'Open the texture while preserving the two large pulses.',
        transitionCue: 'CRASH_ONLY',
        coachingNote: 'Let beat 4 remain a strong internal landmark.',
      },
      {
        id: 'bridge', name: 'Bridge Build', bars: 8, energy: 2,
        chordProgression: ['Am', 'F', 'C', 'G'],
        grooveHint: 'Build gradually across eight bars.',
        transitionCue: 'BUILD',
        coachingNote: 'Keep counting internally even while dynamics grow.',
      },
      {
        id: 'outro', name: 'Outro', bars: 4, energy: 1,
        chordProgression: ['F', 'G', 'C', 'C'],
        grooveHint: 'Return to simple two-pulse feel.',
        transitionCue: 'NO_FILL',
        coachingNote: 'Finish with space and a confident final landing.',
      },
    ],
    variations: [
      {
        id: 'two-pulse', label: 'Two-pulse 6/8 feel',
        description: 'Emphasize counts 1 and 4 while allowing 2-3 and 5-6 to flow underneath.',
        prerequisiteCompetencyIds: ['comp-meter-68'], kind: 'groove',
      },
      {
        id: '68-groove', label: 'Basic 6/8 worship groove',
        description: 'Keep the cymbal pulse flowing and place the backbeat firmly on count 4.',
        prerequisiteCompetencyIds: ['comp-style-worship-68'], kind: 'groove',
      },
      {
        id: 'sixstroke', label: 'Six-stroke 6/8 application',
        description: 'Use a six-note phrase only if the six-stroke competency is already verified.',
        prerequisiteCompetencyIds: ['comp-rud-six-stroke'], kind: 'fill',
      },
    ],
  },
];

export function getPlayAlongById(id: string): PlayAlongTrack | undefined {
  return PLAY_ALONG_TRACKS.find((track) => track.id === id);
}

export function recommendPlayAlongForCompetency(competencyId?: string | null): PlayAlongTrack {
  if (competencyId) {
    const exact = PLAY_ALONG_TRACKS.find((track) => track.recommendedForCompetencyIds.includes(competencyId));
    if (exact) return exact;
  }
  return PLAY_ALONG_TRACKS[0];
}
